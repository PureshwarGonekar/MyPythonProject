from PyQt5 import QtCore, QtGui, QtWidgets
import mod_6_f1
import sqlite3
from traceback import print_exc
Mybooks=sqlite3.connect('Mybooks_6.db')
curMybooks=Mybooks.cursor()
total=0
i=1
Total_Cost=0
class Ui_MainWindow(object):
    def Find_Price(self):
        name=self.tl1.text()
        if name !=None:
            curMybooks.execute("select * from MyBooks where Title='"+name+"';")
            record=curMybooks.fetchone()
            print(record)
            curMybooks.execute("select Price from MyBooks where Title=='"+name+"';")
            price=curMybooks.fetchone()
            if price != None:
                self.tl2.setText(str(price[0]))
        return

    def Find_Total(self):
        curMybooks.execute("select Price from MyBooks where Title=='"+self.tl1.text()+"';")
        price=curMybooks.fetchone()
        if price!=None and self.tl3.text() !='':
            total=int(self.tl3.text())*price[0]
            print('Total : ',total)
            self.tl4.setText(str(total))
        return
    def Grand_Total(self):
        global Total_Cost
        total=float(self.tl4.text())
        Total_Cost+=total
        self.tl5.setText(str(Total_Cost))
        return

    def Add_Item(self):
        global i
        curMybooks.execute("select * from MyBooks where Title='"+self.tl1.text()+"';")
        bill=curMybooks.fetchone()
        if bill!=None and self.tl3.text()!='' and self.tl4!='':
            print('Item has been added')
            curMybooks.execute("insert into "+mod_6_f1.bill+"(Serial_No, BookId, Book_Title, Author, Price, No_of_Copies,Total) values(?,?,?,?,?,?,?);",(i,bill[0],bill[1],bill[2],bill[3],int(self.tl3.text()),float(self.tl4.text())))
            Mybooks.commit()
            i+=1
            self.Grand_Total()

        self.AddItem.clicked.connect(self.tl1.clear) # type: ignore
        self.AddItem.clicked.connect(self.tl2.clear) # type: ignore
        self.AddItem.clicked.connect(self.tl3.clear) # type: ignore
        self.AddItem.clicked.connect(self.tl4.clear)
        return

    def List_View(self):
        query="SELECT * FROM "+mod_6_f1.bill
        result=Mybooks.execute(query)
        self.tableWidget.setRowCount(0)
        for row_number, row_data in enumerate(result):
            self.tableWidget.insertRow(row_number)
            for column_number,data in enumerate(row_data):
                self.tableWidget.setItem(row_number,column_number,QtWidgets.QTableWidgetItem(str(data)))
        global Total_Cost
        print("Total Cost to pay : ",Total_Cost)
    
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1017, 552)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(90, 60, 111, 31))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(130, 70, 101, 91))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.tl1 = QtWidgets.QLineEdit(self.centralwidget)
        self.tl1.setGeometry(QtCore.QRect(190, 59, 231, 31))
        self.tl1.setObjectName("tl1")
        self.tl2 = QtWidgets.QLineEdit(self.centralwidget)
        self.tl2.setGeometry(QtCore.QRect(190, 100, 231, 31))
        self.tl2.setObjectName("tl2")
        self.findPrice = QtWidgets.QPushButton(self.centralwidget)
        self.findPrice.setGeometry(QtCore.QRect(440, 60, 61, 23))
        self.findPrice.setObjectName("findPrice")
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(80, 140, 431, 16))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(100, 170, 71, 31))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.tl3 = QtWidgets.QLineEdit(self.centralwidget)
        self.tl3.setGeometry(QtCore.QRect(190, 170, 231, 31))
        self.tl3.setObjectName("tl3")
        self.findTotal = QtWidgets.QPushButton(self.centralwidget)
        self.findTotal.setGeometry(QtCore.QRect(440, 170, 61, 23))
        self.findTotal.setObjectName("findTotal")
        self.tl4 = QtWidgets.QLineEdit(self.centralwidget)
        self.tl4.setGeometry(QtCore.QRect(190, 220, 231, 31))
        self.tl4.setObjectName("tl4")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(130, 190, 101, 91))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(740, 10, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.verticalScrollBar = QtWidgets.QScrollBar(self.centralwidget)
        self.verticalScrollBar.setGeometry(QtCore.QRect(990, 40, 16, 491))
        self.verticalScrollBar.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar.setObjectName("verticalScrollBar")
        self.AddItem = QtWidgets.QPushButton(self.centralwidget)
        self.AddItem.setGeometry(QtCore.QRect(210, 300, 81, 31))
        self.AddItem.setObjectName("AddItem")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(90, 380, 101, 91))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.tl5 = QtWidgets.QLineEdit(self.centralwidget)
        self.tl5.setGeometry(QtCore.QRect(190, 410, 161, 31))
        self.tl5.setObjectName("tl5")
        self.Clear = QtWidgets.QPushButton(self.centralwidget)
        self.Clear.setGeometry(QtCore.QRect(330, 300, 81, 31))
        self.Clear.setObjectName("Clear")
        self.Pay = QtWidgets.QPushButton(self.centralwidget)
        self.Pay.setGeometry(QtCore.QRect(370, 400, 81, 51))
        self.Pay.setObjectName("Pay")
        self.line_2 = QtWidgets.QFrame(self.centralwidget)
        self.line_2.setGeometry(QtCore.QRect(110, 350, 351, 16))
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.line_3 = QtWidgets.QFrame(self.centralwidget)
        self.line_3.setGeometry(QtCore.QRect(110, 480, 351, 41))
        self.line_3.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(520, 50, 461, 461))
        self.tableWidget.setRowCount(12)
        self.tableWidget.setColumnCount(7)
        self.tableWidget.setObjectName("tableWidget")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1017, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.Clear.clicked.connect(self.tl1.clear) # type: ignore
        self.Clear.clicked.connect(self.tl2.clear) # type: ignore
        self.Clear.clicked.connect(self.tl3.clear) # type: ignore
        self.Clear.clicked.connect(self.tl4.clear) # type: ignore
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        #Push Button
        self.findPrice.clicked.connect(self.Find_Price)
        self.findTotal.clicked.connect(self.Find_Total)
        self.AddItem.clicked.connect(self.Add_Item)
        self.Pay.clicked.connect(self.List_View)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Book Title :"))
        self.label_2.setText(_translate("MainWindow", "Price :"))
        self.findPrice.setText(_translate("MainWindow", "Find Price"))
        self.label_3.setText(_translate("MainWindow", "Quantity :"))
        self.findTotal.setText(_translate("MainWindow", "Find Total"))
        self.label_4.setText(_translate("MainWindow", "Total :"))
        self.label_5.setText(_translate("MainWindow", "Your Bill"))
        self.AddItem.setText(_translate("MainWindow", "Add Item"))
        self.label_6.setText(_translate("MainWindow", "Total Cost :"))
        self.Clear.setText(_translate("MainWindow", "Clear"))
        self.Pay.setText(_translate("MainWindow", "Pay"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

Mybooks.commit()
Mybooks.close()

