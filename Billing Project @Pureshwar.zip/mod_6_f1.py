import sqlite3
Mybooks=sqlite3.connect('Mybooks_6.db')
curMybooks=Mybooks.cursor()

#using file handling to store billno permanently
f=open('billno.txt','r+')
f.seek(0)
billno=f.read(1)
billno=int(billno)
billno+=1
bill='Bill_'+str(billno)
f.seek(0)
f.truncate()
f.write(str(billno))
f.close()
curMybooks.execute("create table '"+bill+"'(Serial_No INTEGER, BookId INTEGER PRIMARY KEY, Book_Title TEXT (20), Author TEXT, Price REAL, No_of_Copies INTEGER, Total REAL);")

#checking the MyBook table is already exist or not
listOfTables = curMybooks.execute("""SELECT name FROM sqlite_master WHERE type='table'AND name='MyBooks'; """).fetchall()
if listOfTables==[]:
    curMybooks.execute("create table MyBooks(BookId INTEGER PRIMARY KEY, Title TEXT (20), Author TEXT, Price REAL);")
    b1=(101,'India 2020','A.P.J. Abdul Kalam',4599.50)
    b2=(102,'The Future of India','Dr. Bimal Jalan',450.0)
    b3=(103,'End of the Era','C.S. Pandit',499.50)
    b4=(104,'The 3 Mistakes of My Life','Chetan Bhagat',900.0)
    b5=(105,'Eternal India','Indira Gandhi',1199.0)
    b5=(105,'Eternal India','Indira Gandhi',1399.0)
    b6=(106,'The Discovery of India','Jawaharlal Nehru',1500.0)
    b7=(107,'My Experiments with Truth','Mahatma Gandhi',1199.0)
    b8=(108,'Aag Ka Dariya','Qurratulain Hyder',801.0)
    b9=(109,'Ayodhya','P. V. Narasimha Rao',4000.0)
    b10=(110,'The Flight of Pigeons','Ruskin Bond',3500.0)
    book=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10]
    for b in book:
        curMybooks.execute('insert into MyBooks(BookId,Title,Author,Price) values(?,?,?,?);',(b[0],b[1],b[2],b[3]))
    Mybooks.commit()
    Mybooks.close()

